# ShopAssist Chat (WordPress plugin)

Floating chat bubble for the ShopAssist AI proof of concept. Demo use only.

- Settings: Settings > ShopAssist Chat (API URL, API key, show tool calls).
- Tools on the settings page: Test connection, Create demo content.
- The browser calls `/wp-json/shopassist/v1/chat`; WordPress forwards to the ShopAssist API.
- Full setup guide: `docs/WP_DEMO_SETUP.md` in the ShopAssist project.
