<?php
/**
 * Plugin Name: ShopAssist Chat
 * Description: Floating AI chat widget for the ShopAssist AI proof of concept. Demo use only (sample data).
 * Version: 1.0.0
 * Requires PHP: 7.4
 * Text Domain: shopassist-chat
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'SHOPASSIST_VERSION', '1.0.0' );
define( 'SHOPASSIST_DIR', plugin_dir_path( __FILE__ ) );
define( 'SHOPASSIST_URL', plugin_dir_url( __FILE__ ) );

require_once SHOPASSIST_DIR . 'includes/settings.php';
require_once SHOPASSIST_DIR . 'includes/rest.php';
require_once SHOPASSIST_DIR . 'includes/demo-content.php';

/**
 * Load the widget CSS/JS on every front-end page and pass it its settings.
 */
function shopassist_enqueue_assets() {
	wp_enqueue_style( 'shopassist-chat', SHOPASSIST_URL . 'assets/chat.css', array(), SHOPASSIST_VERSION );
	wp_enqueue_script( 'shopassist-chat', SHOPASSIST_URL . 'assets/chat.js', array(), SHOPASSIST_VERSION, true );
	wp_localize_script(
		'shopassist-chat',
		'ShopAssistConfig',
		array(
			'restUrl'     => esc_url_raw( rest_url( 'shopassist/v1/chat' ) ),
			'nonce'       => wp_create_nonce( 'wp_rest' ),
			'showDetails' => (bool) get_option( 'shopassist_show_details', 1 ),
		)
	);
}
add_action( 'wp_enqueue_scripts', 'shopassist_enqueue_assets' );

/**
 * Container the widget script attaches to.
 */
function shopassist_render_root() {
	echo '<div id="shopassist-root"></div>';
}
add_action( 'wp_footer', 'shopassist_render_root' );
